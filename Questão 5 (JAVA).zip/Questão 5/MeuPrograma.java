/* Exercicio 5 (Compile o exemplo prático dos slides 14,15 e 16 da aula 4 )*/

 class MeuPrograma {
    public static void main(String[] args) {
        System.out.println("Minha primeira aplicacao Java!");
    }
}

